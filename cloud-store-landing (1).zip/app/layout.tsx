import "./globals.css"
import { Inter } from "next/font/google"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "YusufHosting - Premium Cloud Solutions",
  description:
    "Discover top-tier cloud solutions including Pterodactyl Panels, WhatsApp Bot Scripts, and Cloud VPS services.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}



import './globals.css'